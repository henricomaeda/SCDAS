Sugestões para a correção dos erros.

1. Caso o projeto não esteja encontrando a fonte de dados:
	a) Extraia nessa mesma pasta esses arquivos;
	b) Remova o arquivo de texto.

2. Caso o design do ReportReview não esteja abrindo:
	a) Apertar em 'Extensões';
	b) Apertar em 'Gerenciar Extensões';
	c) Buscar por 'Microsoft RDLC Report Designer 2022';
	d) Instalar a extensão e reiniciar o programa;
	e) Tentar novamente.